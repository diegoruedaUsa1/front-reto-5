# masterclass2-2022
Este repositorio es para hacer un ejemplo en la masterclass de misiontic USA 2022
